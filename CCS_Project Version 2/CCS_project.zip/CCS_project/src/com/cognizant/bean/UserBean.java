package com.cognizant.bean;

public class UserBean {
	private String uiD;
	private String pasS;
	public String getUiD() {
		return uiD;
	}
	public void setUiD(String uiD) {
		this.uiD = uiD;
	}
	public String getPasS() {
		return pasS;
	}
	public void setPasS(String pasS) {
		this.pasS = pasS;
	}
	

}
