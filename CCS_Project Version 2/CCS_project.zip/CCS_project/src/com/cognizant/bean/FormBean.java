package com.cognizant.bean;

public class FormBean {
	private String fnamE;
	private String lnamE;
	private String agE;
	private String gendeR;
	private String ContacT;
	private String statuS;
	private String uiD;
	private String pasS;
	public String getFnamE() {
		return fnamE;
	}
	public void setFnamE(String fnamE) {
		this.fnamE = fnamE;
	}
	public String getLnamE() {
		return lnamE;
	}
	public void setLnamE(String lnamE) {
		this.lnamE = lnamE;
	}
	public String getAgE() {
		return agE;
	}
	public void setAgE(String agE) {
		this.agE = agE;
	}
	public String getGendeR() {
		return gendeR;
	}
	public void setGendeR(String gendeR) {
		this.gendeR = gendeR;
	}
	public String getContacT() {
		return ContacT;
	}
	public void setContacT(String contacT) {
		ContacT = contacT;
	}
	public String getStatuS() {
		return statuS;
	}
	public void setStatuS(String statuS) {
		this.statuS = statuS;
	}
	public String getUiD() {
		return uiD;
	}
	public void setUiD(String uiD) {
		this.uiD = uiD;
	}
	public String getPasS() {
		return pasS;
	}
	public void setPasS(String pasS) {
		this.pasS = pasS;
	}

	
	
	

}
